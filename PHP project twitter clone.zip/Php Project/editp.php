
<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
</head>
<body>
<header>
    <!-- Your header code here -->
</header>

<section>
    <!-- Your edit profile form code here -->
</section>

<footer>
    <!-- Your footer code here -->
</footer>
</body>
</html>
